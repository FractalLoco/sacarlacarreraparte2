import { useState, useEffect } from "react";
import { Plus, Edit, ChevronRight, FileText, Download, Package, CheckCircle, Clock,
         Truck, Building2, Thermometer, AlertCircle } from "lucide-react";
import { lotesAPI, tunelesAPI, reportesAPI, proveedoresAPI, conductoresAPI } from "../api/client";
import { C, iS, fmt, fmtFecha } from "../constants/theme";
import { useAuth } from "../context/AuthContext";
import { useResponsive } from "../hooks/useResponsive";

const ESTADOS = {
  pendiente:  {label:"Pendiente",  bg:"#f1f5f9",text:"#64748b"},
  en_proceso: {label:"En Proceso", bg:"#dcfce7",text:"#15803d"},
  cerrado:    {label:"Cerrado",    bg:"#dbeafe",text:"#1d4ed8"},
};

const ESTADOS_CARGA = ["Fresco","Con hielo","Congelado","Descongelado","Otro"];

// Modal con overlay correcto
const ModalLote = ({ form, set, onClose, onGuardar, esNuevo, proveedores, conductores }) => {
  const [tab, setTab] = useState("basico"); // "basico" | "transporte" | "recepcion"

  const TABS = [
    {id:"basico",      label:"Datos del Lote"},
    {id:"transporte",  label:"Transporte"},
    {id:"recepcion",   label:"Recepción"},
  ];

  return (
    <div onClick={e=>{if(e.target===e.currentTarget)onClose();}}
      style={{position:"fixed",inset:0,zIndex:200,display:"flex",alignItems:"flex-start",justifyContent:"center",overflowY:"auto",padding:"20px 12px",background:"rgba(10,26,74,.72)",backdropFilter:"blur(4px)"}}>
      <div onClick={e=>e.stopPropagation()}
        style={{background:"white",borderRadius:20,width:"100%",maxWidth:640,overflow:"hidden",boxShadow:"0 30px 80px rgba(0,0,0,.45)",display:"flex",flexDirection:"column",margin:"auto 0",animation:"popIn .22s cubic-bezier(.34,1.56,.64,1) both"}}>

        {/* Header */}
        <div style={{padding:"16px 22px",background:`linear-gradient(135deg,${C.blue900},${C.blue700})`,display:"flex",justifyContent:"space-between",alignItems:"center",flexShrink:0}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <Package size={18} color="white"/>
            <span style={{color:"white",fontWeight:800,fontSize:15}}>{esNuevo?"Registrar Nuevo Lote":"Editar Lote"}</span>
          </div>
          <button onClick={onClose} style={{background:"rgba(255,255,255,.1)",border:"none",borderRadius:8,width:32,height:32,cursor:"pointer",color:"white",fontSize:18,display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
        </div>

        {/* Tabs */}
        <div style={{display:"flex",background:"#f8faff",borderBottom:`1px solid ${C.border}`,flexShrink:0}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"11px 8px",border:"none",background:"none",borderBottom:`2px solid ${tab===t.id?C.blue600:"transparent"}`,color:tab===t.id?C.blue700:C.textMut,fontWeight:tab===t.id?700:500,fontSize:12,cursor:"pointer",fontFamily:"inherit",transition:"all .15s"}}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Contenido scrolleable */}
        <div style={{overflowY:"auto",flex:1,padding:22,WebkitOverflowScrolling:"touch"}}>

          {/* TAB: Datos básicos */}
          {tab==="basico" && (
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
              {[
                {k:"codigo",              l:"Código Lote",          ph:"JIB7524",   req:true, span:1},
                {k:"fecha_ingreso",       l:"Fecha Ingreso",        type:"date",    req:true, span:1},
                {k:"kilos_brutos",        l:"Kilos Brutos",         type:"number",  req:true, span:2},
                {k:"proveedor_guia",      l:"Proveedor Guía",       ph:"Proveedor", span:1},
                {k:"guia_despacho",       l:"N° Guía de Despacho",  ph:"12345",     span:1},
                {k:"proveedor_factura",   l:"Proveedor Factura",    ph:"Proveedor", span:1},
                {k:"factura_numero",      l:"N° Factura",           ph:"76543",     span:1},
                {k:"folio_abastecimiento",l:"Folio Abastecimiento", span:1},
                {k:"folio_produccion",    l:"Folio Producción",     span:1},
                {k:"observacion",         l:"Observación general",  ta:true, span:2},
              ].map(({k,l,ph,req,span,type,ta})=>(
                <div key={k} style={{gridColumn:span===2?"span 2":"auto"}}>
                  <label style={{display:"block",fontSize:11,fontWeight:700,color:C.blue700,textTransform:"uppercase",letterSpacing:.5,marginBottom:6}}>{l}{req&&<span style={{color:C.danger}}> *</span>}</label>
                  {ta
                    ? <textarea rows={2} value={form[k]||""} onChange={e=>set(k,e.target.value)} style={{...iS,resize:"none"}}/>
                    : <input type={type||"text"} min={type==="number"?0:undefined} value={form[k]||""} onChange={e=>set(k,type==="number"?e.target.value:e.target.value)} placeholder={ph} style={iS}/>
                  }
                </div>
              ))}
            </div>
          )}

          {/* TAB: Transporte */}
          {tab==="transporte" && (
            <div style={{display:"flex",flexDirection:"column",gap:16}}>
              {/* Proveedor registrado */}
              <div style={{background:C.blue50,borderRadius:12,padding:16,border:`1px solid ${C.blue100}`}}>
                <p style={{fontWeight:700,fontSize:13,color:C.blue900,marginBottom:12,display:"flex",alignItems:"center",gap:7}}><Building2 size={15}/> Proveedor / Empresa Proveedora</p>
                <div style={{display:"grid",gridTemplateColumns:"1fr",gap:10}}>
                  <div>
                    <label style={{display:"block",fontSize:11,fontWeight:700,color:C.blue700,textTransform:"uppercase",letterSpacing:.5,marginBottom:6}}>Seleccionar Proveedor Registrado</label>
                    <select value={form.proveedor_id||""} onChange={e=>set("proveedor_id",+e.target.value||null)} style={iS}>
                      <option value="">— Sin proveedor registrado —</option>
                      {proveedores.map(p=><option key={p.id} value={p.id}>{p.nombre} · {p.rut}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              {/* Conductor */}
              <div style={{background:C.blue50,borderRadius:12,padding:16,border:`1px solid ${C.blue100}`}}>
                <p style={{fontWeight:700,fontSize:13,color:C.blue900,marginBottom:12,display:"flex",alignItems:"center",gap:7}}><Truck size={15}/> Conductor y Vehículo</p>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                  <div style={{gridColumn:"span 2"}}>
                    <label style={{display:"block",fontSize:11,fontWeight:700,color:C.blue700,textTransform:"uppercase",letterSpacing:.5,marginBottom:6}}>Seleccionar Conductor Registrado</label>
                    <select value={form.conductor_id||""} onChange={e=>{
                      const id=+e.target.value||null;
                      set("conductor_id",id);
                      if(id){
                        const c=conductores.find(x=>x.id===id);
                        if(c?.patente_habitual) set("patente_camion",c.patente_habitual);
                        if(c?.empresa_transporte) set("empresa_transporte",c.empresa_transporte);
                      }
                    }} style={iS}>
                      <option value="">— Sin conductor registrado —</option>
                      {conductores.map(c=><option key={c.id} value={c.id}>{c.nombre} · {c.rut}{c.empresa_transporte?" · "+c.empresa_transporte:""}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={{display:"block",fontSize:11,fontWeight:700,color:C.blue700,textTransform:"uppercase",letterSpacing:.5,marginBottom:6}}>Patente del Camión</label>
                    <input value={form.patente_camion||""} onChange={e=>set("patente_camion",e.target.value.toUpperCase())} placeholder="ABCD12" style={{...iS,fontFamily:"monospace",letterSpacing:1,textTransform:"uppercase"}}/>
                  </div>
                  <div>
                    <label style={{display:"block",fontSize:11,fontWeight:700,color:C.blue700,textTransform:"uppercase",letterSpacing:.5,marginBottom:6}}>Empresa Transportista</label>
                    <input value={form.empresa_transporte||""} onChange={e=>set("empresa_transporte",e.target.value)} placeholder="Si no viene registrado" style={iS}/>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: Recepción */}
          {tab==="recepcion" && (
            <div style={{display:"flex",flexDirection:"column",gap:16}}>
              {/* Horarios */}
              <div style={{background:C.blue50,borderRadius:12,padding:16,border:`1px solid ${C.blue100}`}}>
                <p style={{fontWeight:700,fontSize:13,color:C.blue900,marginBottom:12,display:"flex",alignItems:"center",gap:7}}><Clock size={15}/> Horarios de Recepción</p>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                  {[
                    {k:"hora_llegada",         l:"Hora de Llegada del Camión"},
                    {k:"hora_inicio_descarga",  l:"Hora Inicio Descarga"},
                    {k:"hora_fin_descarga",     l:"Hora Fin Descarga"},
                  ].map(({k,l})=>(
                    <div key={k} style={{gridColumn: k==="hora_llegada"?"span 2":"auto"}}>
                      <label style={{display:"block",fontSize:11,fontWeight:700,color:C.blue700,textTransform:"uppercase",letterSpacing:.5,marginBottom:6}}>{l}</label>
                      <input type="datetime-local" value={form[k]||(form[k]==="")?"":form[k]||""} onChange={e=>set(k,e.target.value||null)} style={iS}/>
                    </div>
                  ))}
                </div>
              </div>

              {/* Condiciones */}
              <div style={{background:C.blue50,borderRadius:12,padding:16,border:`1px solid ${C.blue100}`}}>
                <p style={{fontWeight:700,fontSize:13,color:C.blue900,marginBottom:12,display:"flex",alignItems:"center",gap:7}}><Thermometer size={15}/> Condiciones al Ingreso</p>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                  <div>
                    <label style={{display:"block",fontSize:11,fontWeight:700,color:C.blue700,textTransform:"uppercase",letterSpacing:.5,marginBottom:6}}>Temperatura de la Carga (°C)</label>
                    <input type="number" step="0.1" value={form.temperatura_carga||""} onChange={e=>set("temperatura_carga",e.target.value||null)} placeholder="Ej: -2.5" style={iS}/>
                  </div>
                  <div>
                    <label style={{display:"block",fontSize:11,fontWeight:700,color:C.blue700,textTransform:"uppercase",letterSpacing:.5,marginBottom:6}}>Estado de la Carga</label>
                    <select value={form.estado_carga||""} onChange={e=>set("estado_carga",e.target.value||null)} style={iS}>
                      <option value="">— Seleccionar —</option>
                      {ESTADOS_CARGA.map(s=><option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div style={{gridColumn:"span 2"}}>
                    <label style={{display:"block",fontSize:11,fontWeight:700,color:C.blue700,textTransform:"uppercase",letterSpacing:.5,marginBottom:6}}>Observación de Recepción</label>
                    <textarea rows={3} value={form.observacion_recepcion||""} onChange={e=>set("observacion_recepcion",e.target.value||null)} placeholder="Condiciones de la carga, incidencias al momento de recibir..." style={{...iS,resize:"none"}}/>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer fijo */}
        <div style={{display:"flex",gap:10,padding:"14px 22px",borderTop:`1px solid ${C.border}`,background:C.blue50,flexShrink:0}}>
          <button onClick={onClose} style={{flex:1,padding:"11px",background:"white",border:`1px solid ${C.border}`,borderRadius:11,color:C.textSub,fontWeight:600,cursor:"pointer",fontFamily:"inherit",fontSize:13}}>Cancelar</button>
          <button onClick={onGuardar} disabled={!form.codigo||!form.kilos_brutos} style={{flex:2,padding:"11px",background:(!form.codigo||!form.kilos_brutos)?"#e2e8f0":`linear-gradient(135deg,${C.blue900},${C.blue600})`,border:"none",borderRadius:11,color:(!form.codigo||!form.kilos_brutos)?C.textMut:"white",fontWeight:700,cursor:"pointer",fontFamily:"inherit",fontSize:13}}>
            {esNuevo?"Registrar Lote":"Guardar Cambios"}
          </button>
        </div>
      </div>
      <style>{`@keyframes popIn{from{opacity:0;transform:scale(.93) translateY(10px)}to{opacity:1;transform:scale(1) translateY(0)}}`}</style>
    </div>
  );
};

export default function Lotes({ onToast, onVerPesajes }) {
  const { esJefe } = useAuth();
  const { isMobile } = useResponsive();
  const [lotes,       setLotes]       = useState([]);
  const [proveedores, setProveedores] = useState([]);
  const [conductores, setConductores] = useState([]);
  const [cargando,    setCargando]    = useState(true);
  const [modal,       setModal]       = useState(null);
  const [esNuevo,     setEsNuevo]     = useState(true);
  const [form,        setForm]        = useState({});
  const [filtros,     setFiltros]     = useState({estado:"",codigo:""});

  const set = (k,v) => setForm(p=>({...p,[k]:v}));

  const cargar = () => {
    setCargando(true);
    lotesAPI.listar(filtros).then(setLotes).catch(e=>onToast(e.message,"error")).finally(()=>setCargando(false));
  };

  useEffect(()=>{
    cargar();
    proveedoresAPI.listar({activo:"true"}).then(setProveedores).catch(()=>{});
    conductoresAPI.listar({activo:"true"}).then(setConductores).catch(()=>{});
  },[filtros]);

  const abrirNuevo = () => {
    setEsNuevo(true);
    setForm({
      codigo:"", fecha_ingreso:new Date().toISOString().slice(0,10),
      kilos_brutos:"", guia_despacho:"", proveedor_guia:"",
      factura_numero:"", proveedor_factura:"", folio_abastecimiento:"", folio_produccion:"",
      proveedor_id:"", conductor_id:"", patente_camion:"", empresa_transporte:"",
      hora_llegada:"", hora_inicio_descarga:"", hora_fin_descarga:"",
      temperatura_carga:"", estado_carga:"", observacion_recepcion:"", observacion:""
    });
    setModal("form");
  };

  const abrirEditar = (l) => {
    setEsNuevo(false);
    setForm({
      ...l,
      fecha_ingreso: l.fecha_ingreso?.slice(0,10)||"",
      hora_llegada: l.hora_llegada ? new Date(l.hora_llegada).toISOString().slice(0,16) : "",
      hora_inicio_descarga: l.hora_inicio_descarga ? new Date(l.hora_inicio_descarga).toISOString().slice(0,16) : "",
      hora_fin_descarga: l.hora_fin_descarga ? new Date(l.hora_fin_descarga).toISOString().slice(0,16) : "",
    });
    setModal("form");
  };

  const guardar = async () => {
    try {
      if (esNuevo) await lotesAPI.crear(form);
      else         await lotesAPI.actualizar(form.id, form);
      onToast(esNuevo?"Lote registrado correctamente":"Lote actualizado");
      setModal(null); cargar();
    } catch(e){ onToast(e.message,"error"); }
  };

  const cambiarEstado = async (lote,estado) => {
    try {
      await lotesAPI.cambiarEstado(lote.id,estado);
      onToast(estado==="en_proceso"?"Lote iniciado":"Lote cerrado");
      cargar();
    } catch(e){ onToast(e.message,"error"); }
  };

  return (
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      {/* Filtros */}
      <div style={{background:"white",borderRadius:14,border:`1px solid ${C.border}`,padding:"12px 16px",display:"flex",gap:10,flexWrap:"wrap",alignItems:"center"}}>
        <input value={filtros.codigo} onChange={e=>setFiltros(p=>({...p,codigo:e.target.value}))} placeholder="Buscar lote..." style={{...iS,flex:1,minWidth:160}}/>
        <select value={filtros.estado} onChange={e=>setFiltros(p=>({...p,estado:e.target.value}))} style={{...iS,width:"auto",cursor:"pointer"}}>
          <option value="">Todos los estados</option>
          <option value="pendiente">Pendiente</option>
          <option value="en_proceso">En Proceso</option>
          <option value="cerrado">Cerrado</option>
        </select>
        {esJefe&&<button onClick={abrirNuevo} style={{display:"flex",alignItems:"center",gap:6,padding:"10px 16px",background:C.blue900,border:"none",borderRadius:10,color:"white",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"inherit",flexShrink:0}}>
          <Plus size={14}/> Nuevo Lote
        </button>}
      </div>

      {/* Lista */}
      {cargando ? <p style={{textAlign:"center",color:C.textMut,padding:40}}>Cargando...</p>
      : lotes.length===0 ? <div style={{background:"white",borderRadius:14,border:`1px solid ${C.border}`,padding:60,textAlign:"center"}}><Package size={36} color={C.textMut} style={{margin:"0 auto 10px"}}/><p style={{fontWeight:700,color:C.textSub}}>Sin lotes registrados</p></div>
      : lotes.map((l,idx)=>{
        const e=ESTADOS[l.estado]||ESTADOS.pendiente;
        const kb=parseFloat(l.kilos_brutos||0);
        const kp=parseFloat(l.kilos_producidos||0);
        return (
          <div key={l.id} style={{background:"white",borderRadius:14,border:`1px solid ${C.border}`,padding:"16px 18px",boxShadow:"0 2px 8px rgba(0,0,0,.05)",animation:`fadeUp .3s ease ${idx*40}ms both`}}>
            {/* Cabecera */}
            <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:10,marginBottom:10}}>
              <div style={{display:"flex",alignItems:"center",gap:12}}>
                <div style={{width:46,height:46,borderRadius:13,background:C.blue50,border:`1px solid ${C.blue100}`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  <Package size={20} color={C.blue600}/>
                </div>
                <div>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
                    <h3 style={{fontWeight:800,fontSize:17,color:C.blue900}}>{l.codigo}</h3>
                    <span style={{padding:"3px 10px",borderRadius:20,fontSize:11,fontWeight:700,background:e.bg,color:e.text}}>{e.label}</span>
                  </div>
                  <p style={{fontSize:12,color:C.textMut}}>{fmtFecha(l.fecha_ingreso)}</p>
                </div>
              </div>
              <div style={{display:"flex",gap:14,flexWrap:"wrap"}}>
                {[{lb:"Kg Brutos",v:`${fmt(l.kilos_brutos)} kg`},{lb:"Producidos",v:`${fmt(l.kilos_producidos)} kg`},{lb:"Rend.",v:kb>0?`${((kp/kb)*100).toFixed(1)}%`:"—"},{lb:"Cajas",v:l.total_cajas||0}].map(({lb,v})=>(
                  <div key={lb} style={{textAlign:"center",minWidth:60}}>
                    <p style={{fontSize:9,color:C.textMut,fontWeight:700,textTransform:"uppercase"}}>{lb}</p>
                    <p style={{fontSize:15,fontWeight:800,color:C.blue900,marginTop:1}}>{v}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Info proveedor/conductor */}
            <div style={{display:"flex",gap:14,flexWrap:"wrap",padding:"8px 0",borderTop:`1px solid ${C.border}`,borderBottom:`1px solid ${C.border}`,marginBottom:10}}>
              {l.proveedor_nombre&&(
                <div style={{display:"flex",alignItems:"center",gap:6,fontSize:12,color:C.textSub}}>
                  <Building2 size={12} color={C.blue500}/>
                  <span style={{fontWeight:600,color:C.text}}>{l.proveedor_nombre}</span>
                  <span style={{color:C.textMut}}>·</span>
                  <span style={{fontFamily:"monospace",fontSize:11}}>{l.proveedor_rut}</span>
                </div>
              )}
              {l.conductor_nombre&&(
                <div style={{display:"flex",alignItems:"center",gap:6,fontSize:12,color:C.textSub}}>
                  <Truck size={12} color={C.blue500}/>
                  <span style={{fontWeight:600,color:C.text}}>{l.conductor_nombre}</span>
                  {l.patente_camion&&<span style={{background:C.blue900,color:"white",borderRadius:5,padding:"1px 7px",fontFamily:"monospace",fontSize:11,fontWeight:700}}>{l.patente_camion}</span>}
                </div>
              )}
              {l.guia_despacho&&<span style={{fontSize:11,color:C.textMut}}>Guía: <strong style={{color:C.text}}>{l.guia_despacho}</strong></span>}
              {l.factura_numero&&<span style={{fontSize:11,color:C.textMut}}>Factura: <strong style={{color:C.text}}>{l.factura_numero}</strong></span>}
            </div>

            {/* Acciones */}
            <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
              <button onClick={()=>imprimirEtiquetasLote(l.id, l.codigo)}
              style={{display:"flex",alignItems:"center",gap:5,padding:"7px 12px",
                background:"#fef3c7",border:"1px solid #fcd34d",borderRadius:9,
                color:"#92400e",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}
              title="Imprimir todas las etiquetas Zebra de este lote">
              🦓 Etiquetas
            </button>
            <button onClick={()=>onVerPesajes(l)} style={{display:"flex",alignItems:"center",gap:5,padding:"7px 12px",background:C.blue50,border:`1px solid ${C.blue200}`,borderRadius:9,color:C.blue700,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>
                <ChevronRight size={12}/> Ver Pesajes
              </button>
              {esJefe&&l.estado!=="cerrado"&&<button onClick={()=>abrirEditar(l)} style={{display:"flex",alignItems:"center",gap:5,padding:"7px 12px",background:C.blue50,border:`1px solid ${C.blue200}`,borderRadius:9,color:C.blue700,fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}><Edit size={11}/> Editar</button>}
              {esJefe&&l.estado==="pendiente"  &&<button onClick={()=>cambiarEstado(l,"en_proceso")} style={{padding:"7px 12px",background:"#dcfce7",border:"1px solid #a7f3d0",borderRadius:9,color:"#15803d",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",gap:5}}><CheckCircle size={11}/>Iniciar</button>}
              {esJefe&&l.estado==="en_proceso" &&<button onClick={()=>cambiarEstado(l,"cerrado")}    style={{padding:"7px 12px",background:"#dbeafe",border:"1px solid #93c5fd",borderRadius:9,color:"#1d4ed8",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",gap:5}}><Clock size={11}/>Cerrar</button>}
              {l.estado==="cerrado"&&<>
                <button onClick={async()=>{try{onToast("Generando PDF...","info");await reportesAPI.pdf(l.id);onToast("PDF descargado");}catch(e){onToast(e.message,"error");}}} style={{display:"flex",alignItems:"center",gap:5,padding:"7px 12px",background:"#fef2f2",border:"1px solid #fca5a5",borderRadius:9,color:"#dc2626",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}><FileText size={11}/> PDF</button>
                <button onClick={async()=>{try{onToast("Generando Excel...","info");await reportesAPI.excel(l.id);onToast("Excel descargado");}catch(e){onToast(e.message,"error");}}} style={{display:"flex",alignItems:"center",gap:5,padding:"7px 12px",background:"#f0fdf4",border:"1px solid #a7f3d0",borderRadius:9,color:"#15803d",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}><Download size={11}/> Excel</button>
              </>}
            </div>
          </div>
        );
      })}

      {/* Modal formulario */}
      {modal==="form"&&(
        <ModalLote
          form={form} set={set} onClose={()=>setModal(null)}
          onGuardar={guardar} esNuevo={esNuevo}
          proveedores={proveedores} conductores={conductores}
        />
      )}
    </div>
  );
}